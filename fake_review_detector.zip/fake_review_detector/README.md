# 🔍 Fake Review Detection System
### NLP + Machine Learning · Python Flask · College Mini Project

A complete web application that analyses product/service reviews and predicts whether they are **Fake** or **Genuine** using Natural Language Processing and a trained Logistic Regression classifier.

---

## 📁 Project Structure

```
fake_review_detector/
│
├── app.py                 ← Flask app, ML model, all routes
├── requirements.txt       ← Python dependencies
├── reviews.db             ← SQLite DB (auto-created on first run)
│
├── templates/
│   ├── base.html          ← Shared layout + navbar
│   ├── index.html         ← Home page
│   ├── analyze.html       ← Review analysis page (AJAX)
│   └── dashboard.html     ← Admin dashboard with charts
│
├── static/
│   ├── css/
│   │   └── style.css      ← Full UI stylesheet
│   └── js/
│       └── script.js      ← AJAX submission + Chart.js init
│
└── README.md
```

---

## ⚙️ Prerequisites

- Python 3.8 or higher
- pip

---

## 🚀 Installation & Setup

### 1. Unzip and enter the folder
```bash
unzip fake_review_detector.zip
cd fake_review_detector
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv

# Activate:
# macOS / Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

---

## ▶️ Running the Application

```bash
python app.py
```

Open your browser at: **http://127.0.0.1:5000**

> On first run, the model trains automatically (~1 second) and the SQLite DB is created.

---

## 🌐 Pages & Routes

| URL | Page |
|-----|------|
| `/` | Home — project overview |
| `/analyze` | Review analysis form + result |
| `/dashboard` | Admin stats, charts, history |
| `/api/analyze` | POST JSON API for AJAX |
| `/api/stats` | GET live stat counter |

---

## 🤖 How Detection Works

### Step 1 — NLP Preprocessing (NLTK)
- Lowercase conversion
- URL and number removal
- Punctuation stripping
- Stopword removal
- Porter Stemming

### Step 2 — Feature Extraction (scikit-learn)
- TF-IDF vectorizer with unigrams + bigrams
- 2,000 vocabulary features, sublinear TF scaling

### Step 3 — ML Classification
- Logistic Regression classifier
- Trained on 80 hand-labelled reviews (40 fake, 40 genuine)
- Outputs fake probability (0–1)

### Step 4 — Heuristic Signals (rule-based)
| Signal | Description |
|--------|-------------|
| Exclamation density | `!` count / total characters |
| Caps ratio | UPPERCASE letters / total alpha |
| Promo word score | Known fake-signal vocabulary |
| Repetition score | `1 − unique_words/total_words` |

### Step 5 — Weighted Blend
```
final_score = 0.60 × ML_probability + 0.40 × heuristic_score
verdict = 'Fake' if final_score ≥ 0.50 else 'Genuine'
```

---

## 🗄️ Database Schema

```sql
CREATE TABLE reviews (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    review_text  TEXT NOT NULL,
    label        TEXT NOT NULL,         -- 'Fake' or 'Genuine'
    confidence   REAL NOT NULL,         -- 0–100
    ml_prob      REAL NOT NULL,
    exc_ratio    REAL,
    caps_ratio   REAL,
    sig_score    REAL,
    rep_score    REAL,
    analyzed_at  TEXT NOT NULL
);
```

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `Flask` | Web framework |
| `scikit-learn` | TF-IDF + Logistic Regression |
| `nltk` | Text preprocessing |
| `pandas` | Data handling |
| `numpy` | Numeric operations |
| `Chart.js` (CDN) | Dashboard charts |

---

## 🎨 UI Features

- Forensic / cyber-intelligence design theme
- Syne + DM Sans typefaces
- AJAX review analysis (no full page reload)
- Animated confidence progress bars
- 4 heuristic signal cards per result
- Human-readable detection reason list
- Quick sample chips for instant testing
- Responsive layout for mobile
- Dashboard: doughnut, trend bar, signal horizontal bar charts
- Live stat counter (auto-refreshes every 30s)

---

## 📄 License

MIT — Free to use for educational purposes.
