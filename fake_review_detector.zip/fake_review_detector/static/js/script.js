/**
 * script.js — Fake Review Detection System
 * Handles:
 *   - AJAX review analysis (no full page reload)
 *   - Character counter
 *   - Sample review injection
 *   - Result panel rendering
 *   - Dashboard Chart.js initialization
 */

'use strict';

/* ── Helpers ─────────────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const esc = (s) => String(s)
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');

/* ── Sample reviews for quick testing ───────────────────────── */
const SAMPLES = {
  fake1: "BEST PRODUCT EVER!!!! I LOVE IT SO MUCH!! BUY NOW BEFORE IT SELLS OUT!! ABSOLUTELY PERFECT!!!",
  fake2: "I received this product for free to write a review. It is simply the most amazing, wonderful, incredible thing I have ever used in my entire life. Must buy immediately!",
  genuine1: "Works as described. The build quality is decent for the price point, though the instructions were a bit unclear. Shipping took five days which was acceptable.",
  genuine2: "I've been using this for about three months. It does the job, nothing extraordinary. Battery life is slightly shorter than advertised but overall I'm satisfied with the purchase.",
};

/* ── Analyze Page ────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {

  // ── Character counter ───────────────────────────────────────
  const textarea  = $('#reviewText');
  const charCount = $('#charCount');
  const analyzeBtn = $('#analyzeBtn');
  const resultArea = $('#resultArea');

  if (textarea && charCount) {
    textarea.addEventListener('input', () => {
      const len = textarea.value.length;
      charCount.textContent = len;
      charCount.style.color = len > 1800 ? '#e63946' : '';
    });
  }

  // ── Sample chip injection ────────────────────────────────────
  document.querySelectorAll('[data-sample]').forEach(chip => {
    chip.addEventListener('click', () => {
      const key = chip.dataset.sample;
      if (textarea && SAMPLES[key]) {
        textarea.value = SAMPLES[key];
        textarea.dispatchEvent(new Event('input'));
        textarea.focus();
      }
    });
  });

  // ── AJAX form submission ─────────────────────────────────────
  const form = $('#analyzeForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const review = textarea.value.trim();
      if (!review) {
        textarea.focus();
        return;
      }

      // Loading state
      analyzeBtn.classList.add('loading');
      analyzeBtn.disabled = true;
      if (resultArea) resultArea.innerHTML = '';

      try {
        const res  = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ review }),
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        renderResult(data, review, resultArea);
      } catch (err) {
        if (resultArea) {
          resultArea.innerHTML = `
            <div style="padding:16px;background:#fff0f0;border:1px solid rgba(230,57,70,.3);
                        border-radius:8px;color:#e63946;font-size:.88rem;">
              ⚠ Error: ${esc(err.message)}
            </div>`;
        }
      } finally {
        analyzeBtn.classList.remove('loading');
        analyzeBtn.disabled = false;
      }
    });
  }

  // ── Dashboard Charts ─────────────────────────────────────────
  initDashboardCharts();
});


/* ── Result Panel Renderer ───────────────────────────────────── */
function renderResult(data, reviewText, container) {
  if (!container) return;

  const isFake       = data.label === 'Fake';
  const panelClass   = isFake ? 'fake'   : 'genuine';
  const icon         = isFake ? '🚨'     : '✅';
  const verdictColor = isFake ? '#e63946': '#2a9d5c';
  const sub          = isFake
    ? 'This review exhibits signs of being fabricated or incentivised.'
    : 'This review appears to be authentic and organically written.';

  const signals = data.signals || {};
  const reasons = data.reasons || [];

  // Truncate long review for display
  const excerpt = reviewText.length > 180
    ? reviewText.slice(0, 180) + '…'
    : reviewText;

  container.innerHTML = `
    <div class="result-panel ${panelClass}">
      <div class="result-header">
        <div class="verdict-icon">${icon}</div>
        <div>
          <div class="verdict-label">${esc(data.label)} Review</div>
          <div class="verdict-sub">${sub}</div>
        </div>
      </div>

      <div class="result-body">
        <!-- Review excerpt -->
        <div class="review-excerpt">${esc(excerpt)}</div>

        <!-- Confidence bars -->
        <div class="conf-row">
          <span class="conf-label">Confidence</span>
          <div class="conf-bar">
            <div class="conf-fill" style="width:0%" data-target="${data.confidence}"></div>
          </div>
          <span class="conf-pct">${data.confidence}%</span>
        </div>

        <div class="conf-row">
          <span class="conf-label">ML Score</span>
          <div class="conf-bar">
            <div class="conf-fill" style="width:0%;background:${verdictColor}88;"
                 data-target="${data.ml_prob}"></div>
          </div>
          <span class="conf-pct" style="color:${verdictColor}88;">${data.ml_prob}%</span>
        </div>

        <!-- Signal grid -->
        <div style="font-size:.74rem;text-transform:uppercase;letter-spacing:.07em;
                    color:var(--ink-3);font-weight:700;margin:18px 0 10px;
                    font-family:'Syne',sans-serif;">
          Heuristic Signals
        </div>
        <div class="signal-grid">
          ${makeSignal('Exclamation Rate', signals.exclamation_ratio)}
          ${makeSignal('Caps Ratio',       signals.caps_ratio)}
          ${makeSignal('Promo Words',      signals.fake_signal_score)}
          ${makeSignal('Repetition',       signals.repetition_score)}
        </div>

        <!-- Reasons -->
        <div style="font-size:.74rem;text-transform:uppercase;letter-spacing:.07em;
                    color:var(--ink-3);font-weight:700;margin:18px 0 8px;
                    font-family:'Syne',sans-serif;">
          Detection Reasons
        </div>
        <ul class="reasons-list">
          ${reasons.map(r => `<li>${esc(r)}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;

  // Animate bars
  requestAnimationFrame(() => {
    container.querySelectorAll('.conf-fill[data-target]').forEach(bar => {
      setTimeout(() => {
        bar.style.width = bar.dataset.target + '%';
      }, 60);
    });
  });

  // Scroll to result
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function makeSignal(label, value) {
  const v = typeof value === 'number' ? value.toFixed(1) : '—';
  return `
    <div class="signal-item">
      <div class="signal-name">${esc(label)}</div>
      <div class="signal-val">${v}%</div>
    </div>`;
}


/* ── Dashboard Charts ────────────────────────────────────────── */
function initDashboardCharts() {
  if (typeof Chart === 'undefined') return;

  const FONT = "'Syne', sans-serif";
  const GRID = 'rgba(0,0,0,0.05)';
  const TEXT = '#9a9890';

  Chart.defaults.font.family = FONT;
  Chart.defaults.color       = TEXT;

  const data = window.DASH_DATA;
  if (!data) return;

  // ── Doughnut: Fake vs Genuine ──────────────────────────────
  const dCtx = document.getElementById('doughnutChart');
  if (dCtx) {
    new Chart(dCtx, {
      type: 'doughnut',
      data: {
        labels: ['Fake', 'Genuine'],
        datasets: [{
          data: [data.fake, data.genuine],
          backgroundColor: ['#e63946cc', '#2a9d5ccc'],
          borderColor:     ['#e63946', '#2a9d5c'],
          borderWidth: 2,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '66%',
        plugins: {
          legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true } },
          tooltip: tooltip_style(),
        },
      },
    });
  }

  // ── Bar: Daily Scan Trend ─────────────────────────────────
  const bCtx = document.getElementById('trendChart');
  if (bCtx && data.daily_labels.length) {
    new Chart(bCtx, {
      type: 'bar',
      data: {
        labels: data.daily_labels,
        datasets: [
          {
            label: 'Total',
            data: data.daily_total,
            backgroundColor: 'rgba(38,70,83,0.7)',
            borderRadius: 4,
            borderSkipped: false,
          },
          {
            label: 'Fake',
            data: data.daily_fake,
            backgroundColor: 'rgba(230,57,70,0.7)',
            borderRadius: 4,
            borderSkipped: false,
          },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top' }, tooltip: tooltip_style() },
        scales: {
          x: { grid: { color: GRID }, ticks: { maxRotation: 30 } },
          y: { grid: { color: GRID }, beginAtZero: true, ticks: { stepSize: 1 } },
        },
      },
    });
  }

  // ── Horizontal bar: Average signals of fake reviews ───────
  const sCtx = document.getElementById('signalChart');
  if (sCtx && data.sig_avgs) {
    const sa = data.sig_avgs;
    new Chart(sCtx, {
      type: 'bar',
      data: {
        labels: ['Exclamation Rate', 'Caps Ratio', 'Promo Words', 'Repetition'],
        datasets: [{
          label: 'Avg % in Fake Reviews',
          data: [sa.exc, sa.caps, sa.sig, sa.rep].map(v => v ? +v.toFixed(1) : 0),
          backgroundColor: [
            'rgba(230,57,70,0.75)', 'rgba(244,162,97,0.75)',
            'rgba(38,70,83,0.75)',  'rgba(42,157,92,0.75)',
          ],
          borderRadius: 4,
          borderSkipped: false,
        }],
      },
      options: {
        indexAxis: 'y',
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: tooltip_style() },
        scales: {
          x: { grid: { color: GRID }, beginAtZero: true, max: 100,
               ticks: { callback: v => v + '%' } },
          y: { grid: { color: GRID } },
        },
      },
    });
  }
}

function tooltip_style() {
  return {
    backgroundColor: '#1a1915',
    borderColor:     '#333',
    borderWidth: 1,
    titleColor: '#f4f3ef',
    bodyColor:  '#9a9890',
    padding: 10,
    cornerRadius: 6,
  };
}
