"""
Fake Review Detection System — app.py
======================================
Backend: Python Flask
Model:   TF-IDF + Logistic Regression (scikit-learn)
NLP:     NLTK for preprocessing
Storage: In-memory list (no DB required for mini-project)
"""

import os
import re
import json
import string
import sqlite3
from datetime import datetime

import nltk
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify, g
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

# ── Download NLTK data (safe to call multiple times) ──────────────────────────
nltk.download('stopwords', quiet=True)
nltk.download('punkt',     quiet=True)

# ── Flask App ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, 'reviews.db')

# ─────────────────────────────────────────────────────────────────────────────
# DATASET  – 80 labelled reviews (0 = Genuine, 1 = Fake)
# Covers a variety of products/services to make the model generalise.
# ─────────────────────────────────────────────────────────────────────────────
TRAINING_DATA = [
    # ── FAKE reviews (label = 1) ──────────────────────────────────────────────
    ("BEST PRODUCT EVER!!!! I LOVE IT SO MUCH BUY NOW!!!!", 1),
    ("Amazing product! Changed my life! Must buy! Best purchase!", 1),
    ("Five stars! Perfect! Excellent! Wonderful! Incredible deal!", 1),
    ("I received this product for free in exchange for my honest review.", 1),
    ("Buy this now! You will not regret it! Best product on the market!", 1),
    ("This product is absolutely perfect in every single way possible!", 1),
    ("OUTSTANDING!!! SUPERB!!! FANTASTIC!!! ORDER NOW BEFORE STOCK RUNS OUT!!!", 1),
    ("Great product great seller great shipping great everything!", 1),
    ("I was asked to write a review. The product is amazing and perfect.", 1),
    ("Fast delivery! Perfect item! Exactly as described! Will buy again!", 1),
    ("This is the best thing I have ever bought in my entire life!", 1),
    ("Excellent quality! Super fast shipping! Amazing seller! 10/10!", 1),
    ("I got this for free and it is the most amazing product ever made.", 1),
    ("WOW WOW WOW!!! Just WOW!! Best product!!!! Buy buy buy!!!", 1),
    ("Product arrived on time. It is absolutely perfect. Highly recommend!", 1),
    ("This changed my life completely! I recommend to everyone I know!", 1),
    ("Perfect perfect perfect! Love love love! Buy it now!", 1),
    ("Sponsored review: this product exceeded all my expectations 100%!", 1),
    ("The seller sent me this free in exchange for a 5-star review.", 1),
    ("Simply the best product I have ever seen in my entire existence!", 1),
    ("AMAZING QUALITY!! FAST SHIPPING!! HIGHLY HIGHLY RECOMMENDED!! BUY NOW!!", 1),
    ("This is a sponsored post. The product is great and I love everything about it.", 1),
    ("Best purchase of my life!! Life changing!! Must buy immediately!!", 1),
    ("Incredible product! Seller is fantastic! Ship was super fast! Perfect!", 1),
    ("This product is a miracle. Changed everything for me. 10 stars if possible!", 1),
    ("I cannot believe how amazing this is. Just buy it trust me!!", 1),
    ("The product is exactly perfect in every way. I love the seller too!", 1),
    ("Got this as a gift review sample. Works perfectly as advertised always.", 1),
    ("This is the most incredible thing I have ever used. Buy buy buy!", 1),
    ("Absolutely flawless product with zero defects. Perfect in every single way.", 1),
    ("Best seller ever! Ships fast! Product perfect! Highly recommend always!", 1),
    ("I have never experienced anything this good in my entire life. Amazing!", 1),
    ("Product is beyond perfect. Exceeded all expectations. Must purchase now!", 1),
    ("Super amazing fantastic wonderful brilliant product. Order immediately!", 1),
    ("I was compensated with a discount to write this review. Great product!", 1),
    ("Wow this product is so amazing I had to write a review immediately!", 1),
    ("Perfect item! Fast delivery! Great seller! Will definitely buy again ASAP!", 1),
    ("Nothing bad to say. Everything about this is 100% perfect always.", 1),
    ("Sponsored: I was given this free to review and it is genuinely fantastic!", 1),
    ("Best of the best product. Nobody makes products this good. Buy now!", 1),

    # ── GENUINE reviews (label = 0) ───────────────────────────────────────────
    ("The product works well but the packaging was a bit damaged on arrival.", 0),
    ("Good quality for the price, though shipping took longer than expected.", 0),
    ("It does what it says. Nothing special, but no complaints either.", 0),
    ("The size runs a bit small. I suggest ordering one size up.", 0),
    ("Works as described. The build quality could be better but it gets the job done.", 0),
    ("I've been using this for two months and it still works fine.", 0),
    ("The instructions were unclear but after some trial I figured it out.", 0),
    ("Decent product. Not as good as the photos suggest, but acceptable.", 0),
    ("Color was slightly different from the website image, but the quality is okay.", 0),
    ("I had an issue with the first unit and the customer service was helpful.", 0),
    ("It's okay for casual use. Wouldn't rely on it for professional work.", 0),
    ("Battery life is shorter than advertised but overall it functions well.", 0),
    ("The product lasted about six months before showing wear. Average durability.", 0),
    ("Simple and functional. Does exactly what the description promises.", 0),
    ("A few minor scratches on arrival but the product itself works perfectly.", 0),
    ("Took a week longer to arrive than estimated. Product quality is fine though.", 0),
    ("My third time buying this brand. Consistent quality, nothing extraordinary.", 0),
    ("It works but squeaks occasionally. Might just need some breaking in.", 0),
    ("Good value for money. I've seen more expensive versions that aren't better.", 0),
    ("Setup was straightforward. Has been reliable for everyday tasks so far.", 0),
    ("The product is solid but heavier than I expected from the description.", 0),
    ("Reasonably well made. Some plastic parts feel cheap but the core is good.", 0),
    ("Had to return the first one due to a defect. Replacement arrived without issue.", 0),
    ("Works as advertised. My only gripe is the charging cable is too short.", 0),
    ("I use this daily and after three months it still performs consistently.", 0),
    ("Looks slightly different from the pictures. Smaller than I anticipated.", 0),
    ("Customer service was slow but eventually resolved my issue satisfactorily.", 0),
    ("Not the best I've used but given the price point it's fair value.", 0),
    ("Some assembly required and the manual has translation errors, but manageable.", 0),
    ("The product does its job. Wouldn't call it life-changing but it's reliable.", 0),
    ("Good durability so far. Survived a drop without any visible damage.", 0),
    ("Mixed feelings. Quality is acceptable but I expected more at this price.", 0),
    ("The smell on first use was quite strong. Faded after a few days of airing.", 0),
    ("Purchased as a gift. Recipient was happy with it so I consider it successful.", 0),
    ("Five months in and still working without any issues. Pleasantly surprised.", 0),
    ("Packaging was excessive but the product inside was in good condition.", 0),
    ("Slightly overpriced but the build quality justifies it somewhat.", 0),
    ("Functionality is solid. Design is a bit plain but that's personal preference.", 0),
    ("Works fine for basic tasks. Not suitable for heavy-duty use.", 0),
    ("Overall satisfied. Would buy from this seller again when I need a replacement.", 0),
]


# ─────────────────────────────────────────────────────────────────────────────
# NLP PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────
_stemmer   = PorterStemmer()
_stopwords = set(stopwords.words('english'))

# Extra red-flag words that strongly signal fake reviews
FAKE_SIGNAL_WORDS = {
    'amazing', 'incredible', 'fantastic', 'perfect', 'outstanding', 'excellent',
    'superb', 'wonderful', 'brilliant', 'flawless', 'extraordinary', 'unbelievable',
    'sponsored', 'free', 'gifted', 'compensated', 'sample', 'must', 'buy', 'now',
    'best', 'greatest', 'ever',
}


def preprocess(text: str) -> str:
    """
    Lowercase → strip punctuation → remove stopwords → stem.
    Returns a cleaned string for TF-IDF vectorisation.
    """
    text  = text.lower()
    text  = re.sub(r'https?://\S+', ' ', text)          # remove URLs
    text  = text.translate(str.maketrans('', '', string.punctuation))
    text  = re.sub(r'\d+', ' ', text)                   # remove numbers
    tokens = text.split()
    tokens = [_stemmer.stem(t) for t in tokens if t not in _stopwords and len(t) > 1]
    return ' '.join(tokens)


def exclamation_ratio(text: str) -> float:
    """Proportion of exclamation marks to total characters."""
    if not text:
        return 0.0
    return text.count('!') / len(text)


def caps_ratio(text: str) -> float:
    """Proportion of uppercase letters to total alphabetic characters."""
    alpha = [c for c in text if c.isalpha()]
    if not alpha:
        return 0.0
    return sum(1 for c in alpha if c.isupper()) / len(alpha)


def fake_signal_score(text: str) -> float:
    """Fraction of words that are known fake-review signal words."""
    words = re.sub(r'[^a-z ]', '', text.lower()).split()
    if not words:
        return 0.0
    hits = sum(1 for w in words if w in FAKE_SIGNAL_WORDS)
    return hits / len(words)


def repetition_score(text: str) -> float:
    """Ratio of unique words to total words — low uniqueness suggests fake."""
    words = text.lower().split()
    if not words:
        return 0.0
    return 1.0 - (len(set(words)) / len(words))


# ─────────────────────────────────────────────────────────────────────────────
# MODEL TRAINING
# ─────────────────────────────────────────────────────────────────────────────
def build_model():
    texts  = [t for t, _ in TRAINING_DATA]
    labels = [l for _, l in TRAINING_DATA]

    processed = [preprocess(t) for t in texts]

    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        max_features=2000,
        sublinear_tf=True,
    )
    X = vectorizer.fit_transform(processed)

    clf = LogisticRegression(max_iter=500, C=1.0, solver='lbfgs')
    clf.fit(X, labels)

    # Quick internal accuracy check
    X_train, X_test, y_train, y_test = train_test_split(
        X, labels, test_size=0.2, random_state=42, stratify=labels
    )
    clf2 = LogisticRegression(max_iter=500, C=1.0, solver='lbfgs')
    clf2.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf2.predict(X_test))
    print(f"[Model] Training complete — held-out accuracy: {acc:.0%}")

    return vectorizer, clf


print("[Model] Training Fake Review Detector…")
VECTORIZER, CLF = build_model()


# ─────────────────────────────────────────────────────────────────────────────
# PREDICTION
# ─────────────────────────────────────────────────────────────────────────────
def predict_review(text: str) -> dict:
    """
    Combine ML probability with heuristic signals to produce a final verdict.

    Returns a dict with:
      - label      : 'Fake' or 'Genuine'
      - confidence : float 0–100
      - ml_prob    : raw ML fake-probability
      - signals    : dict of heuristic scores
      - reasons    : list of human-readable explanation strings
    """
    processed = preprocess(text)
    X         = VECTORIZER.transform([processed])
    proba     = CLF.predict_proba(X)[0]   # [prob_genuine, prob_fake]
    ml_fake   = float(proba[1])

    # Heuristic signals
    exc  = exclamation_ratio(text)
    caps = caps_ratio(text)
    sig  = fake_signal_score(text)
    rep  = repetition_score(text)

    # Weighted blend: 60% ML + 40% heuristics
    heuristic_fake = min(1.0, (exc * 2) + (caps * 0.5) + (sig * 1.5) + (rep * 0.5))
    combined       = 0.60 * ml_fake + 0.40 * heuristic_fake
    combined       = float(np.clip(combined, 0.0, 1.0))

    label      = 'Fake'    if combined >= 0.50 else 'Genuine'
    confidence = combined * 100 if label == 'Fake' else (1 - combined) * 100

    # Build human-readable reasons
    reasons = []
    if exc > 0.02:
        reasons.append(f"High exclamation-mark density ({exc:.1%})")
    if caps > 0.25:
        reasons.append(f"Excessive use of capital letters ({caps:.1%})")
    if sig > 0.10:
        reasons.append(f"Contains many promotional/signal words ({sig:.1%})")
    if rep > 0.30:
        reasons.append(f"High word repetition detected ({rep:.1%})")
    if ml_fake > 0.60:
        reasons.append(f"ML model strongly suspects fake content ({ml_fake:.1%})")
    if not reasons:
        reasons.append("No strong fake indicators found — language appears natural.")

    return {
        'label':      label,
        'confidence': round(confidence, 1),
        'ml_prob':    round(ml_fake * 100, 1),
        'signals': {
            'exclamation_ratio':  round(exc  * 100, 1),
            'caps_ratio':         round(caps * 100, 1),
            'fake_signal_score':  round(sig  * 100, 1),
            'repetition_score':   round(rep  * 100, 1),
        },
        'reasons': reasons,
    }


# ─────────────────────────────────────────────────────────────────────────────
# DATABASE  (SQLite — stores every analysed review)
# ─────────────────────────────────────────────────────────────────────────────
def get_db():
    db = getattr(g, '_db', None)
    if db is None:
        db = g._db = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_db(exc):
    db = getattr(g, '_db', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.execute('''
            CREATE TABLE IF NOT EXISTS reviews (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                review_text TEXT NOT NULL,
                label       TEXT NOT NULL,
                confidence  REAL NOT NULL,
                ml_prob     REAL NOT NULL,
                exc_ratio   REAL,
                caps_ratio  REAL,
                sig_score   REAL,
                rep_score   REAL,
                analyzed_at TEXT NOT NULL
            )
        ''')
        db.commit()


def save_review(text, result):
    db = get_db()
    db.execute('''
        INSERT INTO reviews
            (review_text, label, confidence, ml_prob,
             exc_ratio, caps_ratio, sig_score, rep_score, analyzed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        text,
        result['label'],
        result['confidence'],
        result['ml_prob'],
        result['signals']['exclamation_ratio'],
        result['signals']['caps_ratio'],
        result['signals']['fake_signal_score'],
        result['signals']['repetition_score'],
        datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    ))
    db.commit()


# ─────────────────────────────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """Home page."""
    return render_template('index.html')


@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    """Review analysis page — shows form and (after POST) results."""
    result      = None
    review_text = ''

    if request.method == 'POST':
        review_text = request.form.get('review', '').strip()
        if review_text:
            result = predict_review(review_text)
            save_review(review_text, result)

    return render_template('analyze.html',
                           result=result,
                           review_text=review_text)


@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    """JSON API endpoint for AJAX analysis (used by the frontend JS)."""
    data        = request.get_json(force=True)
    review_text = (data.get('review') or '').strip()
    if not review_text:
        return jsonify({'error': 'No review text provided.'}), 400

    result = predict_review(review_text)
    save_review(review_text, result)
    return jsonify(result)


@app.route('/dashboard')
def dashboard():
    """Admin dashboard with statistics and recent reviews."""
    db = get_db()

    total   = db.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    fake    = db.execute("SELECT COUNT(*) FROM reviews WHERE label='Fake'").fetchone()[0]
    genuine = db.execute("SELECT COUNT(*) FROM reviews WHERE label='Genuine'").fetchone()[0]

    avg_conf = db.execute(
        "SELECT AVG(confidence) FROM reviews"
    ).fetchone()[0] or 0

    # Last 15 reviews
    recent = db.execute(
        "SELECT * FROM reviews ORDER BY id DESC LIMIT 15"
    ).fetchall()

    # Daily trend (last 7 days)
    daily_rows = db.execute('''
        SELECT substr(analyzed_at, 1, 10) AS day,
               COUNT(*) AS total,
               SUM(CASE WHEN label='Fake' THEN 1 ELSE 0 END) AS fake_count
        FROM reviews
        GROUP BY day
        ORDER BY day DESC
        LIMIT 7
    ''').fetchall()
    daily_rows = list(reversed(daily_rows))

    daily_labels = [r['day'] for r in daily_rows]
    daily_total  = [r['total'] for r in daily_rows]
    daily_fake   = [r['fake_count'] for r in daily_rows]

    # Top signals averages
    sig_avgs = db.execute('''
        SELECT
          AVG(exc_ratio)  AS exc,
          AVG(caps_ratio) AS caps,
          AVG(sig_score)  AS sig,
          AVG(rep_score)  AS rep
        FROM reviews WHERE label='Fake'
    ''').fetchone()

    return render_template(
        'dashboard.html',
        total=total,
        fake=fake,
        genuine=genuine,
        avg_conf=round(avg_conf, 1),
        recent=recent,
        daily_labels=json.dumps(daily_labels),
        daily_total=json.dumps(daily_total),
        daily_fake=json.dumps(daily_fake),
        sig_avgs=sig_avgs,
    )


@app.route('/api/stats')
def api_stats():
    """Live stats JSON — polled every 30s by the dashboard."""
    db      = get_db()
    total   = db.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    fake    = db.execute("SELECT COUNT(*) FROM reviews WHERE label='Fake'").fetchone()[0]
    genuine = total - fake
    return jsonify({'total': total, 'fake': fake, 'genuine': genuine})


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
